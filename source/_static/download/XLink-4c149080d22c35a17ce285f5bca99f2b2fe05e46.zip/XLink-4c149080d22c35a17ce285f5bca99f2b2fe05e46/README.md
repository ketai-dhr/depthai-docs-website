# XLink
This is a "fork" of openvino repositories third party dependency - XLink.

# Changes
Some tweaks to CMake files to enable installation of this target and being able to be used with Hunter package manager