// Copyright (C) 2018-2021 Intel Corporation
// SPDX-License-Identifier: Apache-2.0
//

///
/// @file
/// @brief     Application configuration Leon header
///

#define X_LINK_VERSION_MAJOR 1
#define X_LINK_VERSION_MINOR 0
#define X_LINK_VERSION_PATCH 0
